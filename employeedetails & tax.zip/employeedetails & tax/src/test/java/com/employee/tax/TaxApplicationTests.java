package com.employee.tax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
